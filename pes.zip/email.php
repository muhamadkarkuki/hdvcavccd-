<?php
$emailku = 'pswlwapvgnryxa@cutradition.com'; // Ky xD
?>