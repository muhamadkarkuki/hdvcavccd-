<?php
date_default_timezone_set('Asia/Jakarta');
$jamasuk = date('l, d-m-Y h:i:s');

$author = 'PES';
$sender = 'pes <result@pes.com>';
?>